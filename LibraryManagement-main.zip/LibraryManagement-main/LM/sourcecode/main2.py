import tkinter as tk
import csv
import os
from user_page import user_entry



# Create the main window
root = tk.Tk()
root.title("Library Management System")
root.geometry("1024x768")  # Set the main window dimensions to 2050x768
root.resizable(True, True)

# Set a custom background image
background_image = tk.PhotoImage(file="/Users/gauravi/Desktop/LibraryManagement-main/LM/sourcecode/covers/bg3.png")
background_label = tk.Label(root, image=background_image)
background_label.place(relwidth=1, relheight=1)


# Center the heading at the top
heading_frame = tk.Frame(root)
heading_frame.pack(side="top", pady=20)
heading_label = tk.Label(heading_frame, text="Welcome to the Library Management System", font=("Times New Roman", 50))
heading_label.pack()

# Create a frame for buttons and center-align them
button_frame = tk.Frame(root)
button_frame.pack(expand=True, padx=5, pady=5)
admin_button = tk.Button(button_frame, text="ADMIN ONLY",font=("Times New Roman", 50))
admin_button.pack(fill="x", padx=5, pady=5)

# Pack the buttons with center and top alignment

button_frame2=tk.Frame(root)
button_frame.pack(expand=True, padx=50, pady=50)
user_button = tk.Button(button_frame, text="USERS", command=user_entry, font=("Times New Roman", 50))
user_button.pack(fill="x", padx=50, pady=50)


# Run the main loop
root.mainloop()

