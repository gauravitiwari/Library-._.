import tkinter as tk
from tkinter import scrolledtext
import csv
import os


def user_entry():
    
    def register_window():
            def user_screen():
                 
                 
                 user_name = name_entry.get()  # Get the user's name from the Entry widget

    # Ensure the "Users" folder exists
                 users_folder = "Users"
                 if not os.path.exists(users_folder):
                    os.mkdir(users_folder)

    # Check if the user's CSV file already exists
                 user_csv_file = os.path.join(users_folder, f"{user_name}.csv")
                 if not os.path.exists(user_csv_file):
        # Create a new user CSV file
                    with open(user_csv_file, mode="w", newline='') as new_user_file:
                        writer = csv.writer(new_user_file)
                        writer.writerow(["Book Title", "Date Borrowed", "ISBN"])
                 register_window.destroy()


            register_window = tk.Toplevel()
            register_window.title("Register")
            register_window.geometry("300x130")  # Set window dimensions to 400x300
            register_window.resizable(False, False)  # Make the window size fixed

            

            name_label = tk.Label(register_window, text="Enter Full Name:")
            name_label.pack()
            name_entry = tk.Entry(register_window)
            name_entry.pack()

            phone_label = tk.Label(register_window, text="Enter Phone Number:")
            phone_label.pack()
            phone_entry = tk.Entry(register_window)
            phone_entry.pack()

            submit_button = tk.Button(register_window, text="Submit", command=user_screen)
            submit_button.pack()


            if __name__ == "__main__":
    # Create the main application window
               root = tk.Tk()
               root.title("Library Management System")
               root.geometry("1024x768")  # Set window dimensions to 1024x768


    #AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
    def login_window():
            login_window = tk.Toplevel()
            login_window.title("Login")
            login_window.geometry("300x130")  # Set window dimensions to 400x300
            login_window.resizable(False, False)  # Make the window size fixed

            name_label = tk.Label(login_window, text="Enter Full Name:")
            name_label.pack()
            name_entry = tk.Entry(login_window)
            name_entry.pack()

            submit_button = tk.Button(login_window, text="Submit")
            submit_button.pack()

            if __name__ == "__main__":
    # Create the main application window
               root = tk.Tk()
               root.title("Library Management System")
               root.geometry("1024x768")  # Set window dimensions to 1024x768
    #AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA


    user_window = tk.Toplevel()
    user_window.title("User Window")
    user_window.geometry("650x400")  # Set window dimensions to 1024x768

    # Center the title label and reduce its font size
    title_label = tk.Label(user_window, text="Joining for the first time? Please Register:", font=("Times New Roman", 34))
    title_label.pack(pady=(20, 0))

    # Create a frame for search and clear buttons, side by side with a gap
    button_frame = tk.Frame(user_window)
    button_frame.pack()

    register_button = tk.Button(button_frame, text="REGISTER", command=register_window, font=("Times New Roman", 40))
    register_button.pack(side="left", padx=10)

    login_button = tk.Button(button_frame, text="LOGIN", command=login_window, font=("Times New Roman", 40))
    login_button.pack(side="left", padx=10)

if __name__ == "__main__":
    # Create the main application window
    root = tk.Tk()
    root.title("Library Management System")
    root.geometry("1024x768")  # Set window dimensions to 1024x768

    # Start the main event loop
    root.mainloop()
